/* Module 4 */

/* 1 */
select cust_id, count(*) as number_of_accounts from account
group by cust_id;

/* 2 */
select cust_id, count(*) as number_of_accounts from account
group by cust_id having count(*) >2;

/* 3 */
select fname, birth_date from individual
order by birth_date desc;

/* 4 */
select year(open_date), avg(avail_balance) from account
group by year(open_date) having avg(avail_balance) > 2000
order by year(open_date);

/* 5 */
select product_cd, max(pending_balance) from account
where product_cd in ('CHK', 'SAV', 'CD')
group by product_cd;