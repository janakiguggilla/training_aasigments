/* module 5 */

/* 1 */
select fname, title, name from employee join department
on employee.dept_id = department.dept_id;

/* 2 */
select product_type.name, product.name 
from product_type left join product
on product_type.product_type_cd = product.product_type_cd;

/* 3 */
select 
concat(a.fname,' ',b.lname) as employee_full_name,
concat(a.fname,' ',b.lname) as superior_name
from employee a inner join employee b
on a.superior_emp_id = b.emp_id;

/* 4 */
select   fname,lname from employee
where
superior_emp_id = (select emp_id from employee
where fname='Susan' and lname='Hawthorne');

/* 5 */
select fname,lname from employee
where
emp_id in (select superior_emp_id from employee where dept_id=1);