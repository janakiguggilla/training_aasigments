/*Module 1 */

/* 1*/
CREATE database training;
/*2*/
use training;
create table demography 
(
CustID int PRIMARY KEY auto_increment,
Name varchar(50),
Age int,
Gender varchar(1)

);
/*3*/
insert into demography values(1,'John',25,'M');

/*4*/
insert into demography (Name,Age,Gender) values ('Pawan',26,'M'),('Hema',31,'F');
/*5*/
insert into demography (Name,Gender) values ('Rekha', 'F');
/*6*/
select * from demography;
/*7*/
update demography SET Age=NULL WHERE Name='John';
/*8*/
select * from demography where Age=NULL;
/*9*/
delete from demography;
/*10*/
drop table demography;