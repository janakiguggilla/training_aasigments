/*Module 3 */

/* 1 */

select count(*) from account;
/* 2 */

select * from account limit 2;

/* 3 */

select * from account limit 2,2;

/* 4*/

select year(birth_date) , month(birth_date), day(birth_date),  weekday(birth_date) from individual;

/* 5 */

select substring('Please find the substring in this string', 17, 9);

/* 6 */

select abs(-25.76823);
select round(-25.76823);
select sign(-25.76823);

/* 7 */

select date_add(curdate(), interval 30 day);

/* 8 */

select substring(fname, 1, 3),
substring(lname, -3)
from individual;

select ucase(fname) from individual
where length(fname) =5;

/* 10 */

select max(avail_balance), avg(avail_balance) from individual
where cust_id = 1;